clc;
clear;

iteration = 25;
% W = waitbar(0, 'Verifying...', 'windowstyle', 'modal', 'name', 'DO-DAT');

sysVer = cell(iteration, 1);
result = zeros(iteration, 7);
for it = 1:1:iteration
    %     waitbar(it/iteration, W);
    % Plant degree
    numDegree = 1;
    denDegree = 2;
    nu = denDegree-numDegree;
    
    % Setup
    N = zeros(2, numDegree);
    D = zeros(2, denDegree);
    Nn = zeros(1, numDegree);
    
    Dn = zeros(1, denDegree);
    urealN = umat(zeros(1, numDegree));
    urealD = umat(zeros(1, denDegree));
    
    % Numerator of the plant
    temp = sort(5.*rand(2,1));
    N(:,1) = temp;
    Nn(1,1) = temp(1)+(temp(2)-temp(1)).*rand(1,1);
    for i = 2:1:numDegree
        temp = sort(-5 + 10.*rand(2,1));
        N(:,i) = temp;
        Nn(1,i) = temp(1)+(temp(2)-temp(1)).*rand(1,1);
    end
    for i = 1:1:numDegree
        numUncertain = ureal(strcat('numUncertain', num2str(i)), Nn(1,i), 'Range', [N(1,i), N(2,i)]);
        urealN(1,i) = numUncertain;
    end
    
    % Denominator of the plant
    temp = sort(5.*rand(2,1));
    D(:,1) = temp;
    Dn(1,1) = temp(1)+(temp(2)-temp(1)).*rand(1,1);
    for j = 2:1:denDegree
        temp = sort(-5 + 10.*rand(2,1));
        D(:,j) = temp;
        Dn(1,j) = temp(1)+(temp(2)-temp(1)).*rand(1,1);
    end
    for j = 1:1:denDegree
        denUncertain = ureal(strcat('denUncertain', num2str(j)), Dn(1,j), 'Range', [D(1,j), D(2,j)]);
        urealD(1,j) = denUncertain;
    end
    
    % Verification
    P = tf(urealN, urealD);
    Pn = tf(Nn, Dn);
    C = tf(pidtune(Pn, 'PI'));
    PnC = series(C, Pn);
    sys = feedback(PnC, 1);
    sysEnv = setup_sys(N, D, Pn, C);
    sysVer{it,1} = sysEnv;
    if isstable(sys)
        if sysEnv.nominalStab == 1
            if sysEnv.minPhase == 1
                Q = gen_Qone(nu, sysEnv);
                checkResult = isFastDynamicsStable(Q, sysEnv);
                tau_approx = get_maxTau(Q, sysEnv, 'approx', 3);
                tau_exact = get_maxTau(Q, sysEnv, 'exact');
                if isequal(tau_approx, inf) || isequal(tau_exact, inf)
                    result(it, 1) = checkResult;
                    result(it, 2) = tau_approx;
                    result(it, 3) = tau_exact;
                    result(it, 4:7) = ones(1,4);
                else
                    tau_pass_approx = 0.9*tau_approx;
                    tau_fail_approx = 1.1*tau_approx;
                    passResult = isValidTau(Q, sysEnv, tau_pass_approx);
                    failResult = isValidTau(Q, sysEnv, tau_fail_approx);
                    result(it, 1) = checkResult;
                    result(it, 2) = tau_approx;
                    result(it, 3) = tau_exact;
                    result(it, 4) = passResult;
                    result(it, 5) = failResult;
                    
                    % Verification by ureal
                    numQ = Q.num{1};
                    numQ = numQ(find(numQ):end);
                    denQ = Q.den{1};
                    denQ = denQ(find(denQ):end);
                    numQ_pass = numQ.*(tau_pass_approx.^[length(numQ)-1:-1:0]);
                    denQ_pass = denQ.*(tau_pass_approx.^[length(denQ)-1:-1:0]);
                    Q_pass = tf(numQ_pass, denQ_pass);
                    numQ_fail = numQ.*(tau_fail_approx.^[length(numQ)-1:-1:0]);
                    denQ_fail = denQ.*(tau_fail_approx.^[length(denQ)-1:-1:0]);
                    Q_fail = tf(numQ_fail, denQ_fail);
                    
                    rToy_pass = feedback(C*feedback(P*feedback(1, -Q_pass), Q_pass/Pn), 1);
                    [wcg1_pass, ~] = wcgain(rToy_pass);
                    dToy_pass = feedback(P, (C+Q_pass/Pn)*feedback(1, -Q_pass));
                    [wcg2_pass, ~] = wcgain(dToy_pass);
                    
                    if isinf(wcg1_pass.UpperBound) || isinf(wcg1_pass.LowerBound)
                        result(it, 6) = 0;
                    else
                        result(it, 6) = 1;
                    end
                    
                    rToy_fail = feedback(C*feedback(P*feedback(1, -Q_fail), Q_fail/Pn), 1);
                    [wcg1_fail, ~] = wcgain(rToy_fail);
                    dToy_fail = feedback(P, (C+Q_fail/Pn)*feedback(1, -Q_fail));
                    [wcg2_fail, ~] = wcgain(dToy_fail);
                    
                    if isinf(wcg1_fail.UpperBound) || isinf(wcg1_fail.LowerBound)
                        result(it, 7) = 0;
                    else
                        result(it, 7) = 1;
                    end
                end
            else
                continue;
            end
        else
            continue;
        end
    else
        continue;
    end
end

% close(W);

result

