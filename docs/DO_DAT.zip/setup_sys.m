function sysEnv = setup_sys(N, D, P_n, C)
% By Hamin Chang 06JUL20
% This function returns a structure variable that contains the 
% information about the system environment that will be used later in
% designing the DOB.
%
% sysEnv = setup_sys(Numerator, Denominator, Nominal plant, Controller)
%
% Numerator and Denominator represent the numerator and denominator of a
% given set of uncertain plants, respectively, and they must be entered in 
% the form of a cell that contains both upper and lower bounds of
% all the coefficients. Nominal plant and Controller must be entered in the
% form of a transfer function model.

%% Basic
sysEnv = struct;
sysEnv.P_n = P_n;
sysEnv.C = C;
lengthN = length(N);
tempN = ones(2, lengthN);
for i = 1:1:lengthN
    if length(N{i}) == 1
        tempN(1,i) = N{i};
        tempN(2,i) = N{i};
    else
        tempN(1,i) = N{i}(1);
        tempN(2,i) = N{i}(2);
    end
end
lengthD = length(D);
tempD = ones(2, lengthD);
for j = 1:1:lengthD
    if length(D{j}) == 1
        tempD(1,j) = D{j};
        tempD(2,j) = D{j};
    else
        tempD(1,j) = D{j}(1);
        tempD(2,j) = D{j}(2);
    end
end
sysEnv.N = tempN;
sysEnv.D = tempD;

%% Stability of the nominal closed-loop system
if isstable(feedback(series(C, P_n), 1))
    sysEnv.nominalStab = 1;
else
    sysEnv.nominalStab = 0;
    warning('The nominal closed-loop system is unstable.')
end

%% Minimum phaseness of the uncertain plant
sysEnv.minPhase = kharitonovy(tempN);

if sysEnv.minPhase == 0
    warning('The set of uncertain plant contains non-minimum phase systems.')
end

end