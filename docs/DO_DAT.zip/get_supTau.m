function supTau = get_supTau(varargin)
% By Hamin Chang 06JUL20
% This function returns the upper bound of the range (0, supTau) such that
% any tau that belongs to the range robustly stabilizes the closed-loop
% system with the DOB designed under Q(s;1).
%
% supTau = get_supTau(System environment, Q(s;1), 'exact')
% supTau = get_supTau(System environment, Q(s;1), 'approx', Resolution)
%
% System environment is expected to be the output of the function 
% setup_sys. Q(s;1) that robustly stabilizes the fast dynamics of the
% closed-loop system must be entered in the form of a transfer function 
% model. For the option 'exact', Symbolic Math Toolbox is required. For the
% option 'approx', Resolution must be entered as a positive integer.

%% Basic and exceptions
sysEnv = varargin{1};
Qcanon = varargin{2};
method = varargin{3};
if strcmpi(method, 'approx') || strcmpi(method, 'approximate')
    res = varargin{4};
    if floor(res) ~= res || res < 0
    error('The resolution must be a positive integer.');
    end
end

if sysEnv.nominalStab == 0
    error('The nominal closed-loop system must be stable.')
end

if sysEnv.minPhase == 0
    error('The set of uncertain plant must not contain non-minimum phase systems.')
end

if isFastDynamicsStable(sysEnv, Qcanon)
else
    error('The fast dynamics of the closed-loop system with DOB must be stable.');
end

C = sysEnv.C;
N_C = C.Numerator{1};
N_C = N_C(find(N_C):end);
D_C = C.Denominator{1};
D_C = D_C(find(D_C):end);

P_n = sysEnv.P_n;
N_n = P_n.Numerator{1};
N_n = N_n(find(N_n):end);
D_n = P_n.Denominator{1};
D_n = D_n(find(D_n):end);

N_Qcanon = Qcanon.Numerator{1};
N_Qcanon = N_Qcanon(find(N_Qcanon):end);
diagN_Qcanon = diag(N_Qcanon);
D_Qcanon = Qcanon.Denominator{1};
D_Qcanon = D_Qcanon(find(D_Qcanon):end);
diagD_Qcanon = diag(D_Qcanon);

boundN = sysEnv.N;
boundD = sysEnv.D;
lengthN = length(boundN(1,:));
lengthD = length(boundD(1,:));
for numsetIndex = 1:lengthN
    numsets{numsetIndex} = boundN(:, numsetIndex);
end
numcell = cell(1, numel(numsets));
[numcell{:}] = ndgrid(numsets{:});
numVertex = unique(cell2mat(cellfun(@(v)v(:), numcell, 'UniformOutput',false)), 'rows');
for densetIndex = 1:lengthD
    densets{densetIndex} = boundD(:, densetIndex);
end
dencell = cell(1, numel(densets));
[dencell{:}] = ndgrid(densets{:});
denVertex = unique(cell2mat(cellfun(@(v)v(:), dencell, 'UniformOutput',false)), 'rows');

%% Vertex set Delta
Delta = {};
numVtxPoly = 0;
for i = 1:length(numVertex(:,1))
    for j = 1:length(denVertex(:,1))
        numVtxPoly = numVtxPoly + 1;
        curdelta1 = conv2(diagD_Qcanon, conv(N_n, polySum(conv(denVertex(j,:), D_C), conv(numVertex(i,:), N_C))));
        curdelta2 = conv2(diagN_Qcanon, conv(D_C, polySum(-conv(denVertex(j,:), N_n), conv(numVertex(i,:), D_n))));
        delta = matSum(curdelta1, curdelta2);
        Delta{numVtxPoly, 1} = delta;
    end
end

%% supTau calculation: Approximation method
if strcmpi(method, 'approx') || strcmpi(method, 'approximate')
    W = waitbar(0, 'Processing...', 'windowstyle', 'modal', 'name', 'DO-DAT');
    waitbarIndex = 0;
    candidate = 0;
    for i = 1:1:numVtxPoly-1
        for j = i+1:1:numVtxPoly
            waitbarIndex = waitbarIndex+1;
            waitbar(2*waitbarIndex/(numVtxPoly*(numVtxPoly-1)+1), W);
            deltai = Delta{i};
            deltaj = Delta{j};
            for k = 1:1:res
                lambda1 = (k-1)/res;
                lambda2 = k/res;
                delta1 = matSum(deltaj, lambda1.*matSum(deltai, -deltaj));
                delta2 = matSum(deltaj, lambda2.*matSum(deltai, -deltaj));
                del = {delta1;delta2};
                [~, colOfdel] = size(delta1);
                chooseIndex = permn([1, 2], colOfdel);
                [numberOfCases, ~] = size(chooseIndex);
                for index1 = 1:1:numberOfCases
                    chosenIndex = chooseIndex(index1, :);
                    khar = [];
                    for index2 = 1:1:colOfdel
                        khar(:, index2) = del{chosenIndex(index2)}(:, index2);
                    end
                    [rowOfkhar, colOfkhar] = size(khar);
                    rhTable = routhtable(mat2cell(khar, rowOfkhar, ones(1, colOfkhar)), num2cell(ones(1, colOfkhar)));
                    for rhIndex = 1:1:length(rhTable{1}(:, 1))
                        numAllRoots = roots(rhTable{1}{rhIndex, 1});
                        numPosRoots = numAllRoots(real(numAllRoots)>0);
                        numPosRealRoots = numPosRoots(imag(numPosRoots)==0);
                        candidate = vertcat(candidate, numPosRealRoots);
                        denAllRoots = roots(rhTable{2}{rhIndex, 1});
                        denPosRoots = denAllRoots(real(denAllRoots)>0);
                        denPosRealRoots = denPosRoots(imag(denPosRoots)==0);
                        candidate = vertcat(candidate, denPosRealRoots);
                    end
                end
            end
        end
    end
    %% Finish
    candidate = sort(unique(candidate));
    numCandidates = length(candidate);
        for finIndex = 1:1:numCandidates-1
            if isValidTau(sysEnv, Qcanon, (candidate(finIndex)+candidate(finIndex+1))/2)
            else
                supTau = candidate(finIndex);
                waitbar(1, W);
                close(W)
                return
            end
        end
    supTau = inf;
    waitbar(1, W);
    close(W)
    
%% supTau calculation: Exact method
elseif strcmpi(method, 'exact')
    if ~isempty(which('syms'))
    else
        error('Symbolic Math Toolbox is necessary for this option.')
    end
    syms t s
    for i = 1:numVtxPoly
        delta = Delta{i, 1};
        [~, colOfdelta] = size(delta);
        symdelta = sym(zeros(1, colOfdelta));
        for j = 1:colOfdelta
            symdelta(1, j) = poly2sym(delta(:, j), t);
        end
        Delta{i} = poly2sym(symdelta, s);
    end
    
    W = waitbar(0, 'Processing...', 'windowstyle', 'modal', 'name', 'DO-DAT');
    waitbarIndex = 0;
    %% Step 1 (Hurwitz vertex polynomial)
    step1 = 0;
    for i = 1:numVtxPoly
        routhTable = routhy(fliplr(coeffs(Delta{i}, s)));
        for j = 1:length(routhTable(:, 1))
            allRoots1 = double(vpasolve(routhTable(j, 1), t));
            posRealRoots1 = allRoots1(real(allRoots1)>0 & imag(allRoots1)==0);
            step1 = vertcat(step1, posRealRoots1);
        end
    end
    step1 = sort(unique(step1));
    
    %% Step 2 (negative real eigenvalues of H-1H)
    step2 = 0;
    for i = 1:numVtxPoly-1
        for j = i+1:numVtxPoly
            waitbarIndex = waitbarIndex+1;
            waitbar(2*waitbarIndex/(numVtxPoly*(numVtxPoly-1)+1), W);
            [Hi, ~] = hurwitz(fliplr(coeffs(Delta{i}, s)));
            [Hj, ~] = hurwitz(fliplr(coeffs(Delta{j}, s)));
            Po = {};
            Po{1} = collect(det(s*eye(size(Hi))-Hi/Hj), s);
            Po{2} = diff(Po{1}, s);
            k = 2;
            while polynomialDegree(Po{k}, s) ~= 0
                k = k+1;
                Po{k} = -collect(polynomialReduce(Po{k-2}, Po{k-1}, s), s);
            end
            const = {};
            leadc = {};
            for m = 1:length(Po)
                Pcoeff = coeffs(Po{m}, s);
                const{m} = Pcoeff(1);
                leadc{m} = Pcoeff(end);
                [numOfConstP, denOfConstP] = numden(const{m});
                [numOfLeadcP, denOfLeadcP] = numden(leadc{m});
                allRoots2 = double(vpasolve(numOfConstP, t));
                posRealRoots2 = allRoots2(real(allRoots2)>0 & imag(allRoots2)==0);
                step2 = vertcat(step2, posRealRoots2);
                allRoots2 = double(vpasolve(numOfLeadcP, t));
                posRealRoots2 = allRoots2(real(allRoots2)>0 & imag(allRoots2)==0);
                step2 = vertcat(step2, posRealRoots2);
                allRoots2 = double(vpasolve(denOfConstP, t));
                posRealRoots2 = allRoots2(real(allRoots2)>0 & imag(allRoots2)==0);
                step2 = vertcat(step2, posRealRoots2);
                allRoots2 = double(vpasolve(denOfLeadcP, t));
                posRealRoots2 = allRoots2(real(allRoots2)>0 & imag(allRoots2)==0);
                step2 = vertcat(step2, posRealRoots2);
            end
        end
    end
    step2 = sort(unique(step2));
    
    %% Finish
    candidate = sort(unique(vertcat(step1, step2)));
    numCandidates = length(candidate);
    for finIndex = 1:1:numCandidates-1
        if isValidTau(sysEnv, Qcanon, (candidate(finIndex)+candidate(finIndex+1))/2)
        else
            supTau = candidate(finIndex);
            waitbar(1, W);
            close(W)
            return
        end
    end
    supTau = inf;
    waitbar(1, W);
    close(W)
end

end