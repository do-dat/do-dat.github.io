function validity = isValidTau(sysEnv, Qcanon, tau)
% By Hamin Chang 06JUL20
% This function returns a logical output that equals to 1 if the
% closed-loop system with the DOB designed under given Q(s;1) and tau is 
% robustly stable or 0 otherwise.
%
% validity = isValidTau(System environment, Q(s;1), Tau)
%
% System environment is expected to be the output of the function 
% setup_sys. Q(s;1) that robustly stabilizes the fast dynamics of the
% closed-loop system must be entered in the form of a transfer function 
% model. Tau must be entered as a positive real number.

%% Basic and exceptions
C = sysEnv.C;
N_C = C.Numerator{1};
N_C = N_C(find(N_C):end);
D_C = C.Denominator{1};
D_C = D_C(find(D_C):end);

P_n = sysEnv.P_n;
N_n = P_n.Numerator{1};
N_n = N_n(find(N_n):end);
D_n = P_n.Denominator{1};
D_n = D_n(find(D_n):end);

N_Qcanon = Qcanon.Numerator{1};
N_Qcanon = N_Qcanon(find(N_Qcanon):end);
N_Q = N_Qcanon.*(tau.^(length(N_Qcanon)-1:-1:0));
D_Qcanon = Qcanon.Denominator{1};
D_Qcanon = D_Qcanon(find(D_Qcanon):end);
D_Q = D_Qcanon.*(tau.^(length(D_Qcanon)-1:-1:0));

boundN = sysEnv.N;
boundD = sysEnv.D;
lengthN = length(boundN(1, :));
lengthD = length(boundD(1, :));
for numsetIndex = 1:lengthN
    numsets{numsetIndex} = boundN(:, numsetIndex);
end
numcell = cell(1, numel(numsets));
[numcell{:}] = ndgrid(numsets{:});
numVertex = unique(cell2mat(cellfun(@(v)v(:), numcell, 'UniformOutput',false)), 'rows');
for densetIndex = 1:lengthD
    densets{densetIndex} = boundD(:, densetIndex);
end
dencell = cell(1, numel(densets));
[dencell{:}] = ndgrid(densets{:});
denVertex = unique(cell2mat(cellfun(@(v)v(:), dencell, 'UniformOutput',false)), 'rows');

if tau <= 0
    error('The tau must be a positive real number.');
end

%% Vertex set Delta
Delta = cell(length(numVertex(:, 1))*length(denVertex(:, 1)), 1);
Deltaindex = 0;
for i = 1:length(numVertex(:, 1))
    for j = 1:length(denVertex(:, 1))
        Deltaindex = Deltaindex + 1;
        p_N = polySum(conv(conv(N_C, N_n), D_Q), conv(conv(N_Q, D_C), D_n));
        p_D = polySum(conv(conv(D_C, N_n), D_Q), -conv(conv(N_Q, D_C), N_n));
        delta = polySum(conv(p_N, numVertex(i,:)), conv(p_D, denVertex(j,:))); 
        Delta{Deltaindex, 1} = delta;
    end
end

%% Step 1 (Hurwitz vertex polynomial)
numVtxPoly = length(Delta);
for i = 1:1:numVtxPoly
    curPoly = Delta{i,1};
    curRoots = roots(curPoly);
    curRoots = curRoots(real(curRoots)>=0);
    if isempty(curRoots)
    else
        validity = 0;
        return
    end
end

%% Step 2 (negative real eigenvalues of H-1H)
for i = 1:1:numVtxPoly-1
    for j = i+1:1:numVtxPoly
        Hi = hurwitz(Delta{i});
        Hj = hurwitz(Delta{j});
        eigVals = eig(Hi/Hj);
        negRealEigs = eigVals(imag(eigVals)==0 & real(eigVals)<0);
        if isempty(negRealEigs)
        else
            validity = 0;
            return
        end
    end
end

validity = 1;

end