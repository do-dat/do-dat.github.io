function [Qrecom, Qcanon, supTau] = DO_DAT(varargin)
% By Hamin Chang 06JUL20
% This function returns recommended transfer function models Q(s;tau), 
% Q(s;1), and the upper bound of the range (0, supTau) such that any tau 
% that belongs to the range robustly stabilizes the closed-loop system with
% the DOB designed under Q(s;1).
% 
% [Q(s;tau), Q(s;1), supTau] = DO_DAT(System environment, 'exact')
% [Q(s;tau), Q(s;1), supTau] = DO_DAT(System environment, 'approx', Resolution)
% [Q(s;tau), Q(s;1), supTau] = DO_DAT(System environment, 'approx', Resolution, 'manual', User-defined Q(s;1))
% [Q(s;tau), Q(s;1), supTau] = DO_DAT(System environment, 'approx', Resolution, 'r.degreeOfQ', Relative degree of Q(s;1))
% [Q(s;tau), Q(s;1), supTau] = DO_DAT(System environment, 'approx', Resolution, 'r.degreeOfQ', Relative degree of Q(s;1), 'rhoRoots', LHP roots)
% 
% System environment is expected to be the output of the function 
% setup_sys. For the option 'exact', Symbolic Math Toolbox is required. For
% the option 'approx', Resolution must be entered as a positive integer.
% For the option 'manual', User-defined Q(s;1) that robustly stabilizes the
% fast dynamics of the closed-loop system must be entered in the form of a 
% transfer function model. For the option 'r.degreeOfQ', Relative degree of
% Q(s;1) must be entered as a positive integer. Refer to the instruction
% manual for detailed explanation of the options.

%% Basic and exceptions
sysEnv = varargin{1};
P_n = sysEnv.P_n;
N_n = P_n.Numerator{1};
N_n = N_n(find(N_n):end);
D_n = P_n.Denominator{1};
D_n = D_n(find(D_n):end);
r = length(D_n)-length(N_n);

%% Qcanon generation
if any(strcmpi(varargin, 'manual'))
    Qcanon = varargin{find(strcmpi(varargin, 'manual'))+1};
    if any(strcmpi(varargin, 'rhoRoots'))
        error('rhoRoots option is unavailable when the manual option is enabled.');
    end
    if any(strcmpi(varargin, 'r.degreeOfQ'))
        error('r.degreeOfQ option is unavailable when the manual option is enabled.');
    end
else
    if any(strcmpi(varargin, 'r.degreeOfQ'))
        n = varargin{find(strcmpi(varargin, 'r.degreeOfQ'))+1};
        if any(strcmpi(varargin, 'rhoRoots'))
            rhoRoots = varargin{find(strcmpi(varargin, 'rhoRoots'))+1};
            Qcanon = gen_Qcanon(sysEnv, n, 'rhoRoots', rhoRoots);
        else
            Qcanon = gen_Qcanon(sysEnv, n);
        end
    else
        if any(strcmpi(varargin, 'rhoRoots'))
            error('rhoRoots option is unavailable when the r.degreeOfQ option is disabled.');
        end
        Qcanon = gen_Qcanon(sysEnv, r);
    end
end

%% supTau calculation
if any(strcmpi(varargin, 'approx'))
    res = varargin{find(strcmpi(varargin, 'approx'))+1};
    supTau = get_supTau(sysEnv, Qcanon, 'approx', res);
elseif any(strcmpi(varargin, 'approxmiate'))
    res = varargin{find(strcmpi(varargin, 'approximate'))+1};
    supTau = get_supTau(sysEnv, Qcanon, 'approx', res);
elseif any(strcmpi(varargin, 'exact'))
    supTau = get_supTau(sysEnv, Qcanon, 'exact');
else
    error('One of the supTau finding options must be enabled.');
end

%% Finish
recomTau = 0.95*supTau;
if isValidTau(sysEnv, Qcanon, recomTau)
    N_Qcanon = Qcanon.Numerator{1};
    N_Qcanon = N_Qcanon(find(N_Qcanon):end);
    D_Qcanon = Qcanon.Denominator{1};
    D_Qcanon = D_Qcanon(find(D_Qcanon):end);
    
    N_Qrecom = N_Qcanon.*(recomTau.^(length(N_Qcanon)-1:-1:0));
    D_Qrecom = D_Qcanon.*(recomTau.^(length(D_Qcanon)-1:-1:0));
    Qrecom = tf(N_Qrecom, D_Qrecom);
else
    error('An unexpected problem has occured. Please contact the developer.');
end