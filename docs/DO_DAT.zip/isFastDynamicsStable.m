function fastDynamicsStab = isFastDynamicsStable(sysEnv, Qcanon)
% By Hamin Chang 06JUL20
% This function returns a logical output that equals to 1 if the fast
% dynamics of the closed-loop system (or the polynomial p_f(s)) is 
% robustly stable or 0 otherwise.
%
% fastDynamicsStab = isFastDynamicsStable(System Environment, Q(s;1))
%
% System environment is expected to be the output of the function 
% setup_sys. Q(s;1) must be entered in the form of a transfer function 
% model.

%% Basic
P_n = sysEnv.P_n;
N_n = P_n.Numerator{1};
N_n = N_n(find(N_n):end);
D_n = P_n.Denominator{1};
D_n = D_n(find(D_n):end);

N_Qcanon = Qcanon.Numerator{1};
N_Qcanon = N_Qcanon(find(N_Qcanon):end);
D_Qcanon = Qcanon.Denominator{1};
D_Qcanon = D_Qcanon(find(D_Qcanon):end);

%% lambda_P (lim of P/P_n)
leadCoeffN = sysEnv.N(:,1);
leadCoeffD = sysEnv.D(:,1);
lower = min([leadCoeffN(1)/leadCoeffD(1), leadCoeffN(1)/leadCoeffD(2), leadCoeffN(2)/leadCoeffD(1), leadCoeffN(2)/leadCoeffD(2)]);
upper = max([leadCoeffN(1)/leadCoeffD(1), leadCoeffN(1)/leadCoeffD(2), leadCoeffN(2)/leadCoeffD(1), leadCoeffN(2)/leadCoeffD(2)]);
lambda_P = (D_n(1)/N_n(1)).*[lower;upper];

%% Edge & Bialas theorem
delta1 = polySum(D_Qcanon, (lambda_P(1,1)-1)*N_Qcanon);
delta2 = polySum(D_Qcanon, (lambda_P(2,1)-1)*N_Qcanon);
rootsOfVtx = vertcat(roots(delta1), roots(delta2));
if isequal(rootsOfVtx, rootsOfVtx(rootsOfVtx < 0))
    H1 = hurwitz(delta1);
    H2 = hurwitz(delta2);
    eigVals = eig(H2/H1);
    negRealEigs = eigVals(imag(eigVals) == 0 & real(eigVals) < 0);
    if isempty(negRealEigs)
        fastDynamicsStab = 1;
    else
        fastDynamicsStab = 0;
    end
else
    fastDynamicsStab = 0;
end

end