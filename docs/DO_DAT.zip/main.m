clc;
clear;

%% Example
N = {[4, 10]};
D = {1, [-10, 10]};
P_n = tf(5, [1 -2]);
C = tf(2, [1 4]);
sysEnv = setup_sys(N, D, P_n, C);
% [Q, Qcanon, supTau] = DO_DAT(sysEnv, 'exact')
Qcanon = gen_Qcanon(sysEnv, 3);
% Qcanon = gen_Qcanon(sysEnv, 3, 'rhoRoots', [-0.1, -2]);  
% Qcanon = tf(1, [1, 1]);
fastDynamicsStab = isFastDynamicsStable(sysEnv, Qcanon);
validity = isValidTau(sysEnv, Qcanon, 0.041);
taustar_approx = get_supTau(sysEnv, Qcanon, 'approx', 10);
% taustar_exact = get_supTau(sysEnv, Qcanon, 'exact');

%% Verification using ureal
tau = 0.0231;
numQ = Qcanon.num{1};
numQ = numQ(find(numQ):end);
denQ = Qcanon.den{1};
denQ = denQ(find(denQ):end);
realnumQ = numQ.*(tau.^[length(numQ)-1:-1:0]);
realdenQ = denQ.*(tau.^[length(denQ)-1:-1:0]);
realQ = tf(realnumQ, realdenQ);
a = ureal('a', -2, 'Range', [-10,10]);
b = ureal('b', 5, 'Range', [4,10]);
P = tf(b, [1 a]);
rToy = feedback(C*feedback(P*feedback(1, -realQ), realQ/P_n), 1);
dToy = feedback(P, (C+realQ/P_n)*feedback(1, -realQ));

%% Display
tau
[wcg_rToy, ~] = wcgain(rToy)
[wcg_dToy, ~] = wcgain(dToy)