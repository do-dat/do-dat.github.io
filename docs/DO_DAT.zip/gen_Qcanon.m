function Qcanon = gen_Qcanon(varargin)
% By Hamin Chang 06JUL20
% This function returns a transfer function model Q(s;1) with a constant
% numerator that robustly stabilizes the fast dynamics of the closed-loop 
% system (or the polynomial p_f(s)).
%
% Qcanon = gen_Qcanon(System environment, Relative degree)
% Qcanon = gen_Qcanon(System environment, Relative degree, 'rhoRoots', LHP roots)
%
% System environment is expected to be the output of the function 
% setup_sys. Relative degree of Q(s;1) (i.e., the degree of the 
% denominator) must be entered as a positive integer. Refer to the 
% instruction manual for detailed explanation of the option 'rhoRoots'.

%% Basic
sysEnv = varargin{1};
n = varargin{2};
P_n = sysEnv.P_n;
N_n = P_n.Numerator{1};
N_n = N_n(find(N_n):end);
D_n = P_n.Denominator{1};
D_n = D_n(find(D_n):end);
r = length(D_n)-length(N_n);

%% Input options and exceptions
if floor(n) ~= n || n < 0
    error('The degree of the denominator must be a positive integer.');
end
if n < r
    error('The relative degree of Q-filter must be greater than or equal to that of the plant.')
end

rootsOfRho = -ones(1, n-1);
if length(varargin) > 2
    option = varargin{3};
    if strcmp(option, 'rhoRoots')
        if n == 1
            error('rhoRoots option is unavailable when the relative degree of the Q-filter equals to 1.');
        else
            rootsOfRho = varargin{4};
            if length(rootsOfRho) ~= n-1
                error('The length of rhoRoots must be equal to (the relative degree of the Q-filter - 1).');
            end
            if isequal(rootsOfRho(rootsOfRho<0), rootsOfRho)
            else
                error('All the elements of rhoRoots must be on the left-half plane.');
            end
        end
    end
end

%% Qcanon generation
rho = poly(rootsOfRho);
a0 = 1;
a0_scale = 1;
while 1
    tempN_Qcanon = a0/a0_scale;
    tempD_Qcanon = [rho, a0/a0_scale];
    tempQcanon = tf(tempN_Qcanon, tempD_Qcanon);
    if isFastDynamicsStable(sysEnv, tempQcanon)
        break;
    end
    a0_scale = 2*a0_scale;
end

N_Qcanon = tempN_Qcanon;
D_Qcanon = tempD_Qcanon;
Qcanon = tf(N_Qcanon, D_Qcanon);

end