clc;
clear;

%% Example
C = tf([0.03798,0.003541], [1 0]);
D = [2.7951,-1.0690,-2.9175;3.5894,3.7572,2.5727];
N = [2.7818;4.8454];
Pn = tf(4.204, [3.219,1.142,0.08394]);
Q = tf(0.7534, [1 1 0.7534]);
params = setupParams(N, D, Pn, C);
pfcondition = isFastDynamicsStable(Q, params);
% tauTestResult = test_tau(Q, params, 0.05);
taustar1 = get_max_tau(Q, params, 'approx', 10);
taustar2 = get_max_tau(Q, params, 'exact');

%% Verification using ureal
tau = 0.9999*taustar2;
numQ = Q.num{1};
numQ = numQ(find(numQ):end);
denQ = Q.den{1};
denQ = denQ(find(denQ):end);
realnumQ = numQ.*(tau.^[length(numQ)-1:-1:0]);
realdenQ = denQ.*(tau.^[length(denQ)-1:-1:0]);
realQ = tf(realnumQ, realdenQ);
a1 = ureal('a1', 3.219, 'Range', [2.7951,3.5894]);
a2 = ureal('a2', 1.142, 'Range', [-1.0690,3.7572]);
a3 = ureal('a3', 0.08394, 'Range', [-2.9175,2.5727]);
b = ureal('b', 4.204, 'Range', [2.7818,4.8454]);
P = tf(b, [a1 a2 a3]);
rToy = feedback(C*feedback(P*feedback(1, -realQ), realQ/Pn), 1);
dToy = feedback(P, (C+realQ/Pn)*feedback(1, -realQ));
[wcg1, ~] = wcgain(rToy)
[wcg2, ~] = wcgain(dToy)