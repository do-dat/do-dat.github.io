function kharitonov = kharitonovy(A)

kharitonov = 0;

lengthA = length(A(1, :));
kharPoly1 = [];
kharPoly2 = [];
kharPoly3 = [];
kharPoly4 = [];

for i = 0:lengthA-1
    if mod(i, 4) == 0
        kharPoly1 = [min(A(:, lengthA-i)), kharPoly1];
        kharPoly2 = [max(A(:, lengthA-i)), kharPoly2];
        kharPoly3 = [min(A(:, lengthA-i)), kharPoly3];
        kharPoly4 = [max(A(:, lengthA-i)), kharPoly4];
    elseif mod(i, 4) == 1
        kharPoly1 = [min(A(:, lengthA-i)), kharPoly1];
        kharPoly2 = [max(A(:, lengthA-i)), kharPoly2];
        kharPoly3 = [max(A(:, lengthA-i)), kharPoly3];
        kharPoly4 = [min(A(:, lengthA-i)), kharPoly4];
    elseif mod(i, 4) == 2
        kharPoly1 = [max(A(:, lengthA-i)), kharPoly1];
        kharPoly2 = [min(A(:, lengthA-i)), kharPoly2];
        kharPoly3 = [max(A(:, lengthA-i)), kharPoly3];
        kharPoly4 = [min(A(:, lengthA-i)), kharPoly4];
    elseif mod(i, 4) == 3
        kharPoly1 = [max(A(:, lengthA-i)), kharPoly1];
        kharPoly2 = [min(A(:, lengthA-i)), kharPoly2];
        kharPoly3 = [min(A(:, lengthA-i)), kharPoly3];
        kharPoly4 = [max(A(:, lengthA-i)), kharPoly4];
    end
end

if isequal(roots(kharPoly1) < 0, ones(lengthA-1, 1))
    if isequal(roots(kharPoly2) < 0, ones(lengthA-1, 1))
        if isequal(roots(kharPoly3) < 0, ones(lengthA-1, 1))
            if isequal(roots(kharPoly4) < 0, ones(lengthA-1, 1))
                kharitonov = 1;
            end
        end
    end
end


end

