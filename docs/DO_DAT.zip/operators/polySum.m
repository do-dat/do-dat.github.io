function coeff_sum = polySum(x1, x2)
% vector x1, x2, coeff_sum
% coeff_sum = x1 + x2

[r1, ~] = size(x1);
[r2, ~] = size(x2);

if r1==r2==1
    x1_order = length(x1);
    x2_order = length(x2);
    if x1_order > x2_order
        new_x1 = x1;
        new_x2 = [zeros(1, x1_order-x2_order) x2];
    else
        new_x1 = [zeros(1, x2_order-x1_order) x1];
        new_x2 = x2;
    end
    coeff_sum = new_x1+new_x2;
else
    x1_order = length(x1);
    x2_order = length(x2);
    if x1_order > x2_order
        new_x1 = x1;
        new_x2 = [zeros(x1_order-x2_order,1); x2];
    else
        new_x1 = [zeros(x2_order-x1_order,1); x1];
        new_x2 = x2;
    end
    coeff_sum = new_x1+new_x2;
end

