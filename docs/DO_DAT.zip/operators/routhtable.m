function vout = routhtable( numpoly, denpoly )
% cell numpoly = poly{1}
% cell denpoly = poly{2}
% cell vout
% vout{1} = routh table�� ���� �Լ�
% vout{2} = routh table�� �и� �Լ�

assignin('base', 'numpoly', numpoly);
assignin('base', 'denpoly', denpoly);

vout = cell(2,1);

[~, n] = size(numpoly);

numTable = cell(n);
denTable = cell(n);

%%% Initialize %%%
if mod(n, 2) == 0
    numTable(1:2, (n/2)+1:n) = {0};
    denTable(1:2, (n/2)+1:n) = {1};
    
else
    numTable(2, (n+1)/2) = {0};
    denTable(2, (n+1)/2) = {1};
    numTable(1:2, ((n+1)/2)+1:n) = {0};
    denTable(1:2, ((n+1)/2)+1:n) = {1};
end

for i = 1:1:n
    if mod(i, 2) == 0
        numTable{2, i/2} = numpoly{:,i};
        denTable{2, i/2} = denpoly{:,i};
    else
        numTable{1, (i+1)/2} = numpoly{:, i};
        denTable{1, (i+1)/2} = denpoly{:, i};
    end
end

%%% Rest of the table %%%
for i = 3:1:n
    for j = 1:1:n
        if j == n
            numTable{i,j} = 0;
            denTable{i,j} = 1;
        else
            numTable{i,j} = polySum(-conv(conv(numTable{i-2,1}, denTable{i-1,1}), conv(denTable{i-2,j+1}, numTable{i-1,j+1})), conv(conv(denTable{i-2,1}, numTable{i-1,1}), conv(numTable{i-2,j+1}, denTable{i-1,j+1})));
            denTable{i,j} = conv(conv(denTable{i-2,1}, numTable{i-1,1}), conv(denTable{i-2,j+1}, denTable{i-1,j+1}));
%             tempInt = integerize(numTable{i,j}, denTable{i,j});
%             numTable{i,j} = tempInt{1};
%             denTable{i,j} = tempInt{2};

%             tempReduct = reduct(numTable{i,j}, denTable{i,j});
%             numTable{i,j} = tempReduct{1};
%             denTable{i,j} = tempReduct{2};
        end
    end
end


vout{1} = numTable;
vout{2} = denTable;

end
